<?php
/*Silence is Golden*/